'use strict';
const path = require('path');
const fsp = require('fs/promises');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const ROOT = path.join(__dirname, '..');
const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const ADMIN_USER = process.env.ADMIN_USERNAME || '';
const ADMIN_PASS = process.env.ADMIN_PASSWORD || '';
const SECRET = process.env.SESSION_SECRET || '';

if (IS_PROD && (!ADMIN_USER || !ADMIN_PASS || !SECRET)) {
  console.error('ADMIN_USERNAME, ADMIN_PASSWORD and SESSION_SECRET must be set in production.');
  process.exit(1);
}
if (!ADMIN_USER || !ADMIN_PASS) console.warn('Admin login is disabled until ADMIN_USERNAME and ADMIN_PASSWORD are set.');

const signingKey = SECRET || crypto.randomBytes(32).toString('hex');
const SESSION_MS = 8 * 60 * 60 * 1000;
const MAX_BACKUPS = 10;
const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const BACKUP_ID_RE = /^\d{10,20}$/;
const TOOL_FIELDS = ['name', 'slug', 'description', 'category', 'icon', 'order', 'featured', 'popular', 'active'];

const FILES = {
  settings: 'settings.json', tools: 'tools.json', categories: 'categories.json',
  announcements: 'announcements.json', analytics: 'analytics.json', adminLogs: 'admin-logs.json'
};

const CATEGORIES = [
  { id: 'calculators', name: 'Calculators', icon: 'calculator' },
  { id: 'text', name: 'Text', icon: 'type' },
  { id: 'developer', name: 'Developer', icon: 'code' },
  { id: 'internet', name: 'Internet', icon: 'globe' },
  { id: 'productivity', name: 'Productivity', icon: 'list-checks' }
];
const CATEGORY_IDS = CATEGORIES.map(c => c.id);

const seedTool = (order, name, slug, description, category, icon, featured = false, popular = false) =>
  ({ id: crypto.randomUUID(), name, slug, description, category, icon, order, featured, popular, active: true, createdAt: new Date().toISOString() });

const DEFAULTS = {
  settings: () => ({
    siteName: 'SAKIB UTILITY HUB',
    tagline: 'All Your Daily Tools in One Place',
    developer: 'Developed by Developer Sakib',
    seoDescription: 'Free online calculators, text, developer and internet tools. Most run privately in your browser.',
    contactEmail: '',
    maintenance: false
  }),
  tools: () => [
    seedTool(1, 'Basic Calculator', 'basic-calculator', 'Evaluate arithmetic expressions instantly.', 'calculators', 'calculator', true, true),
    seedTool(2, 'Percentage Calculator', 'percentage-calculator', 'Find percentages, ratios and percentage change.', 'calculators', 'percent', false, true),
    seedTool(3, 'BMI Calculator', 'bmi-calculator', 'Calculate your Body Mass Index and category.', 'calculators', 'heart-pulse'),
    seedTool(4, 'Word Counter', 'word-counter', 'Count words, characters, sentences and reading time.', 'text', 'file-text', true, true),
    seedTool(5, 'Case Converter', 'case-converter', 'Convert text to upper, lower, title or sentence case.', 'text', 'case-sensitive'),
    seedTool(6, 'JSON Formatter', 'json-formatter', 'Validate, beautify and minify JSON.', 'developer', 'braces', true),
    seedTool(7, 'UUID Generator', 'uuid-generator', 'Generate secure random UUID v4 values.', 'developer', 'fingerprint'),
    seedTool(8, 'Password Generator', 'password-generator', 'Create strong random passwords in your browser.', 'internet', 'key-round', false, true)
  ],
  categories: () => CATEGORIES.map(c => ({ ...c })),
  announcements: () => [],
  analytics: () => ({ totalVisits: 0, toolUsage: {}, daily: {} }),
  adminLogs: () => []
};

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const clean = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const pick = (obj, keys) => Object.fromEntries(keys.filter(k => obj && k in obj).map(k => [k, obj[k]]));
const digest = v => crypto.createHash('sha256').update(String(v)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(digest(a), digest(b));
const sign = id => crypto.createHmac('sha256', signingKey).update(id).digest('hex');

/* ---------- JSON storage: atomic writes, per-file queues, validation ---------- */
const isShape = (name, v) =>
  (name === 'settings' || name === 'analytics') ? (v !== null && typeof v === 'object' && !Array.isArray(v)) : Array.isArray(v);

async function writeAtomic(name, data) {
  const file = path.join(DATA_DIR, FILES[name]);
  const tmp = `${file}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600 });
  await fsp.rename(tmp, file);
}

async function readStore(name) {
  const file = path.join(DATA_DIR, FILES[name]);
  let raw;
  try {
    raw = await fsp.readFile(file, 'utf8');
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    const fresh = DEFAULTS[name]();
    await writeAtomic(name, fresh);
    return fresh;
  }
  try {
    const data = JSON.parse(raw);
    if (!isShape(name, data)) throw new Error('unexpected JSON shape');
    return data;
  } catch (err) {
    await fsp.rename(file, `${file}.corrupt-${Date.now()}`).catch(() => {});
    console.error(`Corrupt ${FILES[name]} moved aside: ${err.message}`);
    const fresh = DEFAULTS[name]();
    await writeAtomic(name, fresh);
    return fresh;
  }
}

const queues = new Map();
function enqueue(name, fn) {
  const next = (queues.get(name) || Promise.resolve()).then(fn);
  queues.set(name, next.catch(() => {}));
  return next;
}
const update = (name, mutate) => enqueue(name, async () => {
  const data = await readStore(name);
  const result = await mutate(data);
  await writeAtomic(name, data);
  return result;
});
const replaceStore = (name, data) => enqueue(name, () => writeAtomic(name, data));

/* ---------- Backups ---------- */
async function createBackup() {
  const id = String(Date.now());
  const dest = path.join(BACKUP_DIR, id);
  await fsp.mkdir(dest, { recursive: true });
  for (const file of Object.values(FILES)) {
    await fsp.copyFile(path.join(DATA_DIR, file), path.join(dest, file));
  }
  const ids = await listBackups();
  for (const old of ids.slice(0, -MAX_BACKUPS)) {
    await fsp.rm(path.join(BACKUP_DIR, old), { recursive: true, force: true });
  }
  return id;
}
async function listBackups() {
  const entries = await fsp.readdir(BACKUP_DIR).catch(() => []);
  return entries.filter(d => BACKUP_ID_RE.test(d)).sort();
}
async function restoreBackup(id) {
  const dir = path.join(BACKUP_DIR, id);
  const staged = {};
  for (const [name, file] of Object.entries(FILES)) {
    let data;
    try { data = JSON.parse(await fsp.readFile(path.join(dir, file), 'utf8')); }
    catch { throw new HttpError(400, `Backup ${id} is missing or damaged (${file}).`); }
    if (!isShape(name, data)) throw new HttpError(400, `Backup ${id} has an invalid ${file}.`);
    staged[name] = data;
  }
  await createBackup(); // safety copy of current data before overwriting
  for (const [name, data] of Object.entries(staged)) await replaceStore(name, data);
}

const logAdmin = (action, detail = '') => update('adminLogs', logs => {
  logs.unshift({ at: new Date().toISOString(), action, detail: String(detail).slice(0, 200) });
  logs.splice(500);
});

/* ---------- Tool validation ---------- */
function parseTool(input, all, selfId) {
  const name = clean(input.name, 60);
  const slug = clean(input.slug, 60).toLowerCase();
  const description = clean(input.description, 240);
  const category = clean(input.category, 40);
  const icon = clean(input.icon, 30) || 'tool';
  const order = Number(input.order ?? 100);
  if (!name) throw new HttpError(400, 'Tool name is required.');
  if (!SLUG_RE.test(slug)) throw new HttpError(400, 'Slug may use lowercase letters, numbers and single hyphens.');
  if (!CATEGORY_IDS.includes(category)) throw new HttpError(400, 'Choose a valid category.');
  if (!Number.isInteger(order) || order < 0 || order > 9999) throw new HttpError(400, 'Display order must be a whole number from 0 to 9999.');
  if (all.some(t => t.slug === slug && t.id !== selfId)) throw new HttpError(409, 'A tool with this slug already exists.');
  return {
    name, slug, description, category, icon, order,
    featured: Boolean(input.featured), popular: Boolean(input.popular), active: input.active !== false
  };
}
const publicTool = t => ({
  id: t.id, name: t.name, slug: t.slug, description: t.description, category: t.category,
  icon: t.icon, featured: t.featured, popular: t.popular, order: t.order
});
const byOrder = (a, b) => a.order - b.order || a.name.localeCompare(b.name);

/* ---------- Sessions (in-memory, signed cookie, CSRF token per session) ---------- */
const sessions = new Map();
const sessionCookie = (value, maxAgeSec) =>
  `sid=${value}; Max-Age=${maxAgeSec}; Path=/; HttpOnly; SameSite=Strict${IS_PROD ? '; Secure' : ''}`;

function getCookie(req, name) {
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}
function currentSession(req) {
  const raw = getCookie(req, 'sid');
  if (!raw || !raw.includes('.')) return null;
  const [id, sig] = raw.split('.');
  if (!safeEqual(sig, sign(id))) return null;
  const s = sessions.get(id);
  if (!s) return null;
  if (s.expires < Date.now()) { sessions.delete(id); return null; }
  return { id, ...s };
}
function requireAdmin(req, res, next) {
  const s = currentSession(req);
  if (!s) return res.status(401).json({ error: 'Please log in to continue.' });
  if (req.method !== 'GET' && !safeEqual(req.get('X-CSRF-Token') || '', s.csrf)) {
    return res.status(403).json({ error: 'Invalid or missing CSRF token. Refresh and try again.' });
  }
  req.session = s;
  next();
}

/* ---------- App ---------- */
const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(express.json({ limit: '20kb' }));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many login attempts. Try again in 15 minutes.' }
});
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 240, standardHeaders: 'draft-7', legacyHeaders: false });

/* Admin API */
const admin = express.Router();

admin.post('/login', loginLimiter, async (req, res) => {
  const username = clean(req.body?.username, 100);
  const password = typeof req.body?.password === 'string' ? req.body.password.slice(0, 200) : '';
  const okUser = safeEqual(username, ADMIN_USER);
  const okPass = safeEqual(password, ADMIN_PASS);
  if (!(ADMIN_USER && ADMIN_PASS && okUser && okPass)) {
    await logAdmin('login.failed', username).catch(() => {});
    throw new HttpError(401, 'Invalid username or password.');
  }
  const id = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(32).toString('hex');
  sessions.set(id, { csrf, expires: Date.now() + SESSION_MS });
  res.setHeader('Set-Cookie', sessionCookie(`${id}.${sign(id)}`, SESSION_MS / 1000));
  await logAdmin('login.success');
  res.json({ authenticated: true, username: ADMIN_USER, csrfToken: csrf });
});

admin.get('/session', (req, res) => {
  const s = currentSession(req);
  res.json(s ? { authenticated: true, username: ADMIN_USER, csrfToken: s.csrf } : { authenticated: false });
});

admin.use(requireAdmin);

admin.post('/logout', async (req, res) => {
  sessions.delete(req.session.id);
  res.setHeader('Set-Cookie', sessionCookie('', 0));
  res.json({ ok: true });
});

admin.get('/dashboard', async (req, res) => {
  const [analytics, tools, logs] = await Promise.all([
    readStore('analytics'), readStore('tools'), readStore('adminLogs')
  ]);
  const usage = analytics.toolUsage || {};
  const popular = Object.entries(usage)
    .sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([slug, uses]) => ({ slug, uses, name: tools.find(t => t.slug === slug)?.name || slug }));
  res.json({
    totalVisits: analytics.totalVisits || 0,
    totalToolUses: Object.values(usage).reduce((a, b) => a + b, 0),
    toolCount: tools.length,
    activeToolCount: tools.filter(t => t.active).length,
    popular,
    recentActivity: logs.slice(0, 10)
  });
});

admin.get('/tools', async (req, res) => {
  res.json((await readStore('tools')).sort(byOrder));
});

admin.post('/tools', async (req, res) => {
  const tool = await update('tools', tools => {
    const parsed = parseTool(req.body || {}, tools, null);
    const t = { id: crypto.randomUUID(), ...parsed, createdAt: new Date().toISOString() };
    tools.push(t);
    return t;
  });
  await logAdmin('tool.created', tool.name);
  res.status(201).json(tool);
});

admin.put('/tools/:id', async (req, res) => {
  const updated = await update('tools', tools => {
    const idx = tools.findIndex(t => t.id === req.params.id);
    if (idx < 0) throw new HttpError(404, 'Tool not found.');
    const current = tools[idx];
    const merged = { ...current, ...pick(req.body || {}, TOOL_FIELDS) };
    tools[idx] = {
      ...parseTool(merged, tools, current.id),
      id: current.id, createdAt: current.createdAt, updatedAt: new Date().toISOString()
    };
    return tools[idx];
  });
  await logAdmin('tool.updated', updated.name);
  res.json(updated);
});

admin.delete('/tools/:id', async (req, res) => {
  const removed = await update('tools', tools => {
    const idx = tools.findIndex(t => t.id === req.params.id);
    if (idx < 0) throw new HttpError(404, 'Tool not found.');
    return tools.splice(idx, 1)[0];
  });
  await logAdmin('tool.deleted', removed.name);
  res.status(204).end();
});

admin.get('/settings', async (req, res) => res.json(await readStore('settings')));

admin.put('/settings', async (req, res) => {
  const b = req.body || {};
  const saved = await update('settings', s => {
    for (const [k, max] of Object.entries({ siteName: 60, tagline: 120, developer: 80, seoDescription: 300, contactEmail: 120 })) {
      if (typeof b[k] === 'string') s[k] = clean(b[k], max);
    }
    if (!s.siteName) throw new HttpError(400, 'Site name cannot be empty.');
    if (s.contactEmail && !EMAIL_RE.test(s.contactEmail)) throw new HttpError(400, 'Contact email is invalid.');
    if (typeof b.maintenance === 'boolean') s.maintenance = b.maintenance;
    return s;
  });
  await logAdmin('settings.updated');
  res.json(saved);
});

admin.get('/announcements', async (req, res) => res.json(await readStore('announcements')));

admin.post('/announcements', async (req, res) => {
  const text = clean(req.body?.text, 200);
  if (!text) throw new HttpError(400, 'Announcement text is required.');
  const item = await update('announcements', list => {
    const a = { id: crypto.randomUUID(), text, active: req.body.active !== false, createdAt: new Date().toISOString() };
    list.unshift(a);
    list.splice(50);
    return a;
  });
  await logAdmin('announcement.created', text.slice(0, 60));
  res.status(201).json(item);
});

admin.delete('/announcements/:id', async (req, res) => {
  const removed = await update('announcements', list => {
    const idx = list.findIndex(a => a.id === req.params.id);
    if (idx < 0) throw new HttpError(404, 'Announcement not found.');
    return list.splice(idx, 1)[0];
  });
  await logAdmin('announcement.deleted', removed.text.slice(0, 60));
  res.status(204).end();
});

admin.post('/backup', async (req, res) => {
  const id = await createBackup();
  await logAdmin('backup.created', id);
  res.status(201).json({ id });
});

admin.get('/backups', async (req, res) => res.json(await listBackups()));

admin.post('/restore', async (req, res) => {
  const id = String(req.body?.id ?? '');
  if (!BACKUP_ID_RE.test(id)) throw new HttpError(400, 'Invalid backup id.');
  await restoreBackup(id);
  await logAdmin('backup.restored', id);
  res.json({ restored: id });
});

/* Public API */
const pub = express.Router();
pub.use(apiLimiter);

pub.get('/settings', async (req, res) => {
  const [s, a] = await Promise.all([readStore('settings'), readStore('analytics')]);
  res.json({
    siteName: s.siteName, tagline: s.tagline, developer: s.developer,
    seoDescription: s.seoDescription, contactEmail: s.contactEmail, maintenance: s.maintenance,
    stats: {
      totalVisits: a.totalVisits || 0,
      totalToolUses: Object.values(a.toolUsage || {}).reduce((x, y) => x + y, 0)
    }
  });
});

pub.get('/tools', async (req, res) => {
  const tools = (await readStore('tools')).filter(t => t.active).sort(byOrder);
  res.json(tools.map(publicTool));
});

pub.get('/tools/:slug', async (req, res) => {
  const t = (await readStore('tools')).find(x => x.active && x.slug === req.params.slug);
  if (!t) throw new HttpError(404, 'Tool not found.');
  res.json(publicTool(t));
});

pub.get('/categories', (req, res) => res.json(CATEGORIES));

pub.get('/announcements', async (req, res) => {
  const list = (await readStore('announcements')).filter(a => a.active).map(({ id, text }) => ({ id, text }));
  res.json(list);
});

pub.post('/analytics/visit', async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  await update('analytics', a => {
    a.totalVisits = (a.totalVisits || 0) + 1;
    a.daily = a.daily || {};
    a.daily[today] = (a.daily[today] || 0) + 1;
    const keep = Object.keys(a.daily).sort().slice(-60);
    a.daily = Object.fromEntries(keep.map(d => [d, a.daily[d]]));
  });
  res.status(204).end();
});

pub.post('/analytics/tool-usage', async (req, res) => {
  const slug = clean(req.body?.slug, 60);
  const tools = await readStore('tools');
  if (!tools.some(t => t.active && t.slug === slug)) throw new HttpError(404, 'Tool not found.');
  await update('analytics', a => {
    a.toolUsage = a.toolUsage || {};
    a.toolUsage[slug] = (a.toolUsage[slug] || 0) + 1;
  });
  res.status(204).end();
});

app.use('/api/admin', admin);
app.use('/api', pub);
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

/* Static pages */
app.get('/admin', (req, res) => res.sendFile(path.join(ROOT, 'admin', 'index.html')));
app.use('/admin', express.static(path.join(ROOT, 'admin')));
app.use(express.static(path.join(ROOT, 'public'), { maxAge: IS_PROD ? '1h' : 0 }));
app.use((req, res) => res.sendFile(path.join(ROOT, 'public', 'index.html')));

/* Errors: never expose stack traces */
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Request body must be valid JSON.' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body is too large.' });
  const status = err instanceof HttpError ? err.status : 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'Something went wrong. Please try again.' : err.message });
});

/* Startup */
async function start() {
  await fsp.mkdir(BACKUP_DIR, { recursive: true });
  for (const name of Object.keys(FILES)) await readStore(name); // creates missing files
  setInterval(() => createBackup().catch(e => console.error('Scheduled backup failed:', e.message)), 24 * 60 * 60 * 1000).unref();
  app.listen(PORT, () => console.log(`SAKIB UTILITY HUB listening on ${PORT} (data: ${DATA_DIR})`));
}
start().catch(err => { console.error('Startup failed:', err.message); process.exit(1); });
