# SAKIB UTILITY HUB

All Your Daily Tools in One Place.
Developed by Developer Sakib.

Stack: Node.js, Express, plain HTML/CSS/JavaScript, JSON files on a persistent disk. No database, no frontend framework.

## Run locally

    npm install
    ADMIN_USERNAME=admin ADMIN_PASSWORD=change-me-now SESSION_SECRET=dev-secret DATA_DIR=./data npm start

Open http://localhost:3000 for the site and http://localhost:3000/admin for the admin login.

## Upload to GitHub

1. Create a new empty repository on GitHub (for example `sakib-utility-hub`).
2. In the project folder run:

       git init
       git add .
       git commit -m "Initial commit: SAKIB UTILITY HUB"
       git branch -M main
       git remote add origin https://github.com/<your-user>/sakib-utility-hub.git
       git push -u origin main

Never commit real passwords. The `.gitignore` already excludes `.env` and the `data/*.json` files.

## Deploy on Render

1. In Render, choose New > Blueprint (or New > Web Service) and connect the GitHub repository. Render reads `render.yaml`.
2. Build command: `npm install`. Start command: `npm start`.
3. Environment variables (Render dashboard > Environment):
   - `NODE_ENV` = `production`
   - `DATA_DIR` = `/var/data`
   - `ADMIN_USERNAME` = your admin username
   - `ADMIN_PASSWORD` = a long, unique password
   - `SESSION_SECRET` = a long random string (`render.yaml` can generate one)
4. Persistent Disk: Render > your service > Disks > Add Disk. Mount path `/var/data`, size 1 GB. Persistent disks require a paid instance type (the blueprint uses `starter`).
5. Deploy. Open `https://<your-service>.onrender.com/admin` and log in.

Data lives in `/var/data`: `settings.json`, `tools.json`, `categories.json`, `announcements.json`, `analytics.json`, `admin-logs.json`, and `backups/`. Writes are atomic (temp file, then rename). If a file is damaged, it is moved aside as `*.corrupt-<time>` and defaults are restored.

## Backups and restore

- A backup is taken every 24 hours and on demand from the admin page ("Create backup now"). The last 10 are kept in `/var/data/backups/<id>/`.
- Restore uses `POST /api/admin/restore` with JSON `{"id":"<backup id>"}` and a valid admin session and CSRF token. Before restoring, the current data is backed up automatically. `GET /api/admin/backups` lists the available IDs.

## Security notes

- Passwords are never stored in files. They are compared with timing-safe hashes.
- Sessions use an HttpOnly, SameSite=Strict cookie that is Secure in production, expires after 8 hours, and is signed with `SESSION_SECRET`.
- Admin state-changing requests require the `X-CSRF-Token` header.
- Login is rate limited to 5 attempts per 15 minutes per IP. The API has a general rate limit.
- Helmet sets security headers. Error responses never include stack traces.
- Sessions are kept in memory, so admins must log in again after a restart.

## Current scope

Included: public site with search, categories, favorites, recent tools, theme toggle, and 8 working tools (basic calculator, percentage, BMI, word counter, case converter, JSON formatter, UUID generator, password generator); admin login, dashboard, tool add/activate/edit description/delete, announcements API, settings API, backups and restore API.
